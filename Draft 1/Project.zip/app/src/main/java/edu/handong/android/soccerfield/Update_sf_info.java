package edu.handong.android.soccerfield;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Update_sf_info extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_sf_info);
    }
}