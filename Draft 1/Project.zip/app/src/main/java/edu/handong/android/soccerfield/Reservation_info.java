package edu.handong.android.soccerfield;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Reservation_info extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reservation_info);
    }
}