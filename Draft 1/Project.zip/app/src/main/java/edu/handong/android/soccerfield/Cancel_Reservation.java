package edu.handong.android.soccerfield;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Cancel_Reservation extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cancel_reservation);
    }
}