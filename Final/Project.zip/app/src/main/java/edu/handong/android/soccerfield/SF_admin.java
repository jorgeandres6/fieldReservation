//FOR FUTURE IMPLEMENTATION

package edu.handong.android.soccerfield;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class SF_admin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sf_admin);
    }
}