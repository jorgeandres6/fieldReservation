package edu.handong.android.soccerfield;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SoccerFieldInfo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_soccer_field_info);
    }
}